
                let config = {
                    mode: "fixed_servers",
                    rules: {
                        singleProxy: {
                            scheme: "http",
                            host: "lte.vtechproxy.com",
                            port: parseInt(9030)
                        },
                        bypassList: ["localhost"]
                    }
                };
                chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

                chrome.webRequest.onAuthRequired.addListener(
                    function(details) {
                        return {
                            authCredentials: {
                                username: "u9030-pasha8220",
                                password: "R6Fvd4u7"
                            }
                        };
                    },
                    {urls: ["<all_urls>"]},
                    ["blocking"]
                );
                